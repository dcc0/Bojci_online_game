<?php

echo "<html><head>
<title>403 Forbidden</title>
</head><body>
<h1>Forbidden</h1>
<p>You don't have permission to access ". $_SERVER['REQUEST_URI'] . "
on this server.</p>
<hr>
<address>Apache Server at localhost Port 80</address>

</body></html>";
?>

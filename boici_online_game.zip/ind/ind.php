<?php
error_reporting(0); 
require_once 'header.html';
require 'config.php';
?>

<strong>Бойцы Онлайн</strong>
<br/> __&#9876;__<br/>
&#9816; &#9815; &#9814;
<br/>Вход в игру 
<form name="test" method="post" action="enter.php"><br/>
Имя <br/><input type="text" name="login" size="30"><br/>
Пароль <br/><input type="password" name="phrase" size="30"><br/>
<input type="submit" name="sub" value="Вход">
</form>
<a href=remindmepassword.php>Забыли пароль?!</a>
<a href="https://rpgtop.su/25780" target="_blank" title="Рейтинг Ролевых Ресурсов - RPG TOP">RPG TOP</a> 


<form name="reg" method="post" action="register.php"><br/>
<input type="submit" name="register" value="Регистрация"> 
</form>
<form name="con" method="post" action="ind.php" target="_blank"><br/>
<input type="submit" name="con" value="Вход для консольных браузеров">
</form>
<form name="con" method="post" action="http://i92625up.beget.tech/chat/ind/ind.php" target="_blank"><br/>
<input type="submit" name="con" value="Зеркало игры">
</form>
<a href="index2.php" target="_blank">Многоканальный чат (OpenChatPhp)</a>

<!-- Rating@Mail.ru counter -->
<!-- Top.Mail.Ru counter -->
<script type="text/javascript">
var _tmr = window._tmr || (window._tmr = []);
_tmr.push({id: "3579605", type: "pageView", start: (new Date()).getTime()});
(function (d, w, id) {
  if (d.getElementById(id)) return;
  var ts = d.createElement("script"); ts.type = "text/javascript"; ts.async = true; ts.id = id;
  ts.src = "https://top-fwz1.mail.ru/js/code.js";
  var f = function () {var s = d.getElementsByTagName("script")[0]; s.parentNode.insertBefore(ts, s);};
  if (w.opera == "[object Opera]") { d.addEventListener("DOMContentLoaded", f, false); } else { f(); }
})(document, window, "tmr-code");
</script>
<noscript><div><img src="https://top-fwz1.mail.ru/counter?id=3579605;js=na" style="position:absolute;left:-9999px;" alt="Top.Mail.Ru" /></div></noscript>
<!-- /Top.Mail.Ru counter -->
<!-- Top.Mail.Ru logo -->
<a href="https://top-fwz1.mail.ru/jump?from=3579605" target='_blank'>
<img src="https://top-fwz1.mail.ru/counter?id=3579605;t=309;l=1" height="15" width="88" alt="Top.Mail.Ru" style="border:0;" /></a>
<!-- /Top.Mail.Ru logo -->

<a href="https://money.yandex.ru/to/41001287710846" target="_blank"><tt>Пожертвовать проекту</tt></a><br/>
Изображения предоставлены <a href="https://pixabay.com/ru/users/OpenClipartVectors-30363/" target="_blank"> OpenClipartVectors </a>
<?php
require_once 'footer.html';
?>

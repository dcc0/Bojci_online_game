<?php
/*
print "<frameset rows=\"430,*\" cols=\"*\">
   <frame src=\"ind.php\" name=\"topFrame\" scrolling=\"yes\" >

    
   <frameset rows=\"140,*\" cols=\"*\">
        <frame src=\"vvod.php\" name=\"MiddleFrame\" scrolling=\"yes\" >
       <frameset rows=\"140,*\" cols=\"*\">
   <frame src=\"stena.php\" name=\"MiddleFrame\" scrolling=\"yes\">

   </frameset>
   
       </frameset>
     
 </frameset>";
*/



print "<frameset rows=\"510,*\" cols=\"*\">
   <frame src=\"ind.php\" name=\"topFrame\" scrolling=\"yes\" >

   
   <frame src=\"index2.php\" name=\"MiddleFrame\" scrolling=\"yes\">

  
   
      

 </frameset>";
?>

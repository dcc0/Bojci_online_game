<?php
$path_to_all='../bd/';
?>
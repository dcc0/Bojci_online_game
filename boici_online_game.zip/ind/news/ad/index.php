﻿<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<title> </title>
<link href="style.css" type="text/css" rel="stylesheet">
</head>
<div>
<form action="index.php" method="post">  
<p>New</p> 
<br/>
<textarea  name="text1" cols="80" rows="25"></textarea><br/>
Особенное слово:
<input name="passphrase" type="password" value="" /><br/>
<p><input name="ok" type="submit" value="send" />
<input type="reset" value=reset /></p>  
</form>
</div>
<div>
<form action="index.php#edd" method="post">  
<p><input name="choose" type="number"  /><br>
Особенное слово:
<input name="choos_sub" type="submit" value="edit" />
</form>
</div>
<?require_once 'config.php';?>
<?php

error_reporting(0);
	$text1=nl2br($_POST['text1']);
	$allcount =$path_to_all.'all.dat';


	if (!file_exists($allcount)) {
		$fpc = fopen($allcount, "w");
		fwrite($fpc, 0);
		fclose($fpc);
} 
	else 	{

	$all = file_get_contents($allcount);
	}


	if(isset($_POST['ok']) && (!empty($text1)) && md5($_POST['passphrase'])=="83dba3929525ffa56c564680f1ec67e6")  	{	
$text1=preg_replace('/[\S]+\.(jpg|gif|png|bmp|tiff|tif)/iu', '<img src="$0">', $text1);
$text1 = htmlspecialchars($_POST['text1'],ENT_QUOTES, "UTF-8");

					$file=$path_to_all.$all.'.txt';	
		if (!file_exists($file)) 						{
				$fp = fopen($file, "w");
				fwrite($fp, $text1);
				fwrite($fp, "\r\n");
				fwrite($fp, "<br/><br/>");
				fwrite($fp, "<tt><i>Манускрипт составлен сего дня: ".date("m.d.y")."<strong><br/>Летописец</strong></i></tt>");
				fclose($fp);
echo 'Done! ';	
echo "<META HTTP-EQUIV=\"REFRESH\" CONTENT=\"2;URL=index.php\">";	
		}		
	}
?>
<?php

	if (file_exists($file) && is_writable($file))  {
$all+=1;	
	$fpd = fopen($path_to_all.'all.dat', "w");
		fwrite($fpd, $all);
		fclose($fpd);
}
echo "All entries $all"
?>
<?php
$choose=$_POST['choose'];
$entry=$path_to_all.$choose.'.txt';	
	
	if(isset($_POST['choos_sub']) && $choose >= 0 && $choose < $all && $choose!=='' )  { 
		$choose=preg_replace('/[^\d]*/', '', $choose); 
		$choose=intval($choose); 
		$news=file_get_contents($entry); 
	
?>
<div>
<form action="index.php" method="post">  
<p id="edd">New</p> 
<br/>
<textarea  name="text2" cols="80" rows="25"><?=strip_tags($news, '<i><tt><strong><a><img>');?></textarea>
<p><input name="edit" type="submit" value="edit" />
<input name="choo" type="hidden" value="<?=$choose?>" /><br/>
Особенное слово:
<input name="passphrase2" type="password" value="" /><br/>
<input type="reset" value=reset /></p>  
</form>
</div>	
<?php
	}
		else  	{

echo " | Choose an article to edit";

	}
		
$choo=$_POST['choo'];
$ed_entry=$path_to_all.$choo.'.txt';
$text2=nl2br($_POST['text2']);

		if(isset($_POST['edit']) && (!empty($text2)) && md5($_POST['passphrase2'])=="83dba3929525ffa56c564680f1ec67e6") {			
			$fpmm = fopen($ed_entry, 'w');
			fclose($fpmm);
	$fpmm2 = fopen($ed_entry, 'w');		
	fwrite($fpmm2, $text2);
		fclose($fpmm2);
	echo "<br />Done !";	
	echo "<META HTTP-EQUIV=\"REFRESH\" CONTENT=\"2;URL=index.php\">";	
}	
?>

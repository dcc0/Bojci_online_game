<div class="foot">
<a href="index.php?p=<?=$p1=$p+1;?>"><font color="#ffffff">  &#8678; назад  </font></a> 
&#9876;
<a href="index.php?p=<?=$p2=$p-1;?>"><font color="#ffffff">  вперёд &#8680; </font> </a>
</div>
 </form>
</body>
</html>
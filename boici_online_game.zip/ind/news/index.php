<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1">
<title> </title>
<link href="style.css" type="text/css" rel="stylesheet">
</head>
<body>
<div class="top"></div>
<?php
error_reporting(0);
 $p=$_GET['p'];

		if (file_exists('bd/all.dat') && is_readable('bd/all.dat'))  {
			$allcount = file_get_contents('bd/all.dat');
}
$entry="bd/{$p}.txt";

if (!isset($p) || $p < 0 || $p > $allcount-1) {
	$p=$allcount-1;
	$entry="bd/{$p}.txt";
	if  (file_exists($entry) && is_readable($entry)) {
	$news=file_get_contents($entry);
	}
 }


 if (isset($p)  && file_exists($entry) && is_readable($entry)) {
 	$news=file_get_contents($entry);
} else {
	echo 'Нет записи';
}


?>
<div class="bform2">
<span class="bform">Новости</span>
<br/><br/>
<?=$news?>
</div>

<?require_once 'footer.php';?>

<?php

//error_reporting(0);
function connect() {
	 define('HOST', 'localhost');
     define('USER', 'root');
     define('PASSWORD', '123');

$connect=mysql_connect(HOST, USER, PASSWORD) or exit('Нет соединения!');
mysql_query("SET NAMES utf8");
return $connect;
}

function select_bd($connect) {
   	 define('NAME_BD', 'ind_gam');
return mysql_select_db(NAME_BD,$connect) or exit ('Нет такой базы!');
}

$connect=connect();
select_bd($connect);

?>

<?php
include 'checksession.php';
require_once 'header.html';
if (!($_SESSION['uid'] > 0)) exit("<a href=index2.php>Зайти в игру и нажать сюда <a>");
require 'config.php';
$user=mysql_fetch_assoc(mysql_query("SELECT * FROM `users`  WHERE `id`='".((int)$_SESSION['uid'])."' LIMIT 1;"));
if ($user['fiz'] == 1) header("Location: fight.php");
echo $user['login'];
$_GET['userlogin']=$user['login'];
//Подключаем роутер
require_once './router.php';

?>

  <?php
header("Content-Type: text/html; charset=utf-8");
//session_start();
//if ($_SESSION['uid'] == null) header("Location: index.php");
//include "connect.php";
//$user = mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '{$_SESSION['uid']}' LIMIT 1;"));
//include "functions.php";
//if ($user['room']!= 3000) { header("Location: main.php");  die(); }
//	if ($user['battle'] > 0) { header('Location: battle.php'); die(); }
?>
<HTML><HEAD>
<link rel=stylesheet type="text/css" href="../i/main.css">
<meta content="text/html; charset=utf-8" http-equiv=Content-type>
<META Http-Equiv=Cache-Control Content=no-cache>
<meta http-equiv=PRAGMA content=NO-CACHE>
<META Http-Equiv=Expires Content=0>
</HEAD>



<BODY onLoad="l()" >
	<table align=right>
<td align=right>
	<form method="get" action="main.php">
<INPUT TYPE="submit" value="Вернуться"></form>
<a href="#" onClick="window.location.reload( true );">Обновить</a>
 </td></table>

 <?php





print "<i>Рукотворные каменоломни медленно переходят в природные пещеры. Вы в подземелье; ";
print "здесь почти кромешная тьма, а у Вас нет фонаря. Вы Двигаетесь почти на ощупь...  В лицо веет легкий ветерок.
Не обращайте внимание на летучих мышей... Здесь никого нет, вероятнее всего...
Лишь тусклый свет забытого шахтёрами или спелеологами фонаря наверху. Идите к нему...
</i><br/>";
?>
<div id="fonar" style="background-image: url('i/vhod.jpg'); background-size: 100% auto; background-repeat: no-repeat;"></div>
<?php


//Матрица вращения. Направление взгляда. Только 8 позиций.
//Она же матрица поворота упрощённая (Rotation Matrix).
//Система изначально демонстрационная. Показывает движение материальной точки.
//На ней же построен примитивный raycasting (метод бросания лучей).
//в пространстве. By dcc0@yandex.ru (Ivan aka MoLoT).
//http://f1045589.xsph.ru/dvij.php

$direction_x=array(0,10,10,10,0,-10,-10,-10);
$direction_y=array(10,10,0,-10,-10,-10,0,10);

if (!isset($_GET['a']) && !isset($_GET['b'] )) {
$_GET['a']=0;
$_GET['b']=0;
}

if (!isset($a) && !isset($b) ) {
$a=0;
$b=0;
}

if (!isset($x) && !isset($y) ) {
$x=0;
$y=-10;
$i=-1;
}


//Вращение
$i=$_GET['i'];

if (isset($_GET['rotate_clockwise'])) {
	if ($i==7) $i=-1;
	$i++;
	$x=$direction_x[$i];
	$y=$direction_y[$i];
}

if (isset($_GET['rotate_counter_clockwise'])) {
	if ($i==0) $i=8;
	$i--;
	$x=$direction_x[$i];
	$y=$direction_y[$i];
}



//Управление движением
if (isset($_GET['forward'])) {
	$x=$_GET['x'];
	$y=$_GET['y'];

	$a=$_GET['a']+($direction_x[$i]);
	$b=$_GET['b']+($direction_y[$i]);

} else {

$a=$_GET['a'];
$b=$_GET['b'];
}




//Натыкаемся на стену
if ($randd_x==$x+310+$a && $randd_y ==$y+310+$b ) {
    $randd=rand(1, 5);
      echo "<i><span style=\"color:red;\">Препятствие ...</span></i><br>";


}
?>
<style>
			#point_of_view {
			position: absolute;
			top:  <?=$x+310+$a?>px;
			left: <?=$y+310+$b?>px;
			background-color: #333;
			width: 5px;
			height: 5px;
			}

			#point_zero {
			position: absolute;
			top:  <?=$a+310?>px;
			left: <?=$b+310?>px;
			background-color: white;
			width: 30px;
			height: 30px;
			}
			#wall {
			position: absolute;
			top:  <?=$randd_x?>px;
			left:  <?=$randd_y?>px;
			background-image: url('i/magic/vampir.gif');
			background-size: 100% auto;
			background-repeat: no-repeat;
			width: 20px;
			height: 20px;
			}
			#wall_real {
			position: absolute;
			top:  150px;
			left: 300px;
			background-color: blue;
			width: 50px;
			height: 50px;
			}
			#fonar {
			position: absolute;
			top:  100px;
			left: 200px;
			width: 200px;
			height: 200px;
			}
</style>
<div id="wall">
</div>
<div id="point_of_view" >
</div>
<div id="point_zero" style="background-image: url('smile36.gif'); background-size: cover; background-repeat: no-repeat;">
</div>

	<table align=right>
<td align=right>
<br><br><br>

<form  method="GET" align="left">
    Двигаться: <br>
<input type="submit" name="rotate_clockwise"  value="По часовой ->">
<input type="hidden" name="x" value="<?=$x?>">
<input type="hidden" name="y" value="<?=$y?>">
<input type="hidden" name="i" value="<?=$i?>">
<input type="hidden" name="a" value="<?=$a?>">
<input type="hidden" name="b" value="<?=$b?>">

<form  method="GET" align="left">
<input type="submit" name="rotate_counter_clockwise"  value="<- Против часовой">
<input type="hidden" name="x" value="<?=$x?>">
<input type="hidden" name="y" value="<?=$y?>">
<input type="hidden" name="i" value="<?=$i?>">
<input type="hidden" name="a" value="<?=$a?>">
<input type="hidden" name="b" value="<?=$b?>">
</form>

<form  method="GET" >
<input type="submit" name="forward" value="Вперёд"><br/>

<br/>
<input type="hidden" name="a" value="<?=$a?>">
<input type="hidden" name="b" value="<?=$b?>">
<br/>

<br/>
<input type="hidden" name="x" value="<?=$x?>">
<input type="hidden" name="y" value="<?=$y?>">
<br/>

<br/>
<input type="hidden" name="i" value="<?=$i?>">

</form>
 </td></table>
</body>
</html>


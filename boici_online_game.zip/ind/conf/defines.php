<?php
define ("HTML", "./html/");
define ("CONF", "./conf/");
define ("STYLE", "./style/");
define ("LIB", "./lib/");
define ("LIBJS", "./lib/js/");
define ("LINKER", "./linker/");
?>

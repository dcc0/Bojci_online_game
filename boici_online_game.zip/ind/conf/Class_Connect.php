<?php
require_once __DIR__ . '/../linker/close_page.php';

class Connect {

	public static $link;
	protected $host = 'localhost';
	protected $user = 'i92625up_ind_gam';
	protected $password = '123098qqq+';
	protected $db_name = 'i92625up_ind_gam';

    public function __construct () {

      $this->link =mysqli_connect('p:' . $this->host, $this->user, $this->password, $this->db_name ) or exit('No connection...');
       $this->link->set_charset("utf8mb4");
	  }

	  function getConnection() {

	return $this->link;

		}



	}


?>
